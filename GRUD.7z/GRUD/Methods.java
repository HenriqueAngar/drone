package br.dio.com;

import java.util.ArrayList;
import java.util.Scanner;

public class Methods {
    static ArrayList<dron> list = new ArrayList<>();
    static int dronQuantity;
    static Scanner sc = new Scanner(System.in);


    static void addingdron() {
        System.out.println("Então você deseja adicionar um drone ao sistema!\nPor favor, digite o nome do drone:");
        String namedron = sc.next();
        System.out.println("Agora, por favor digite o ano do drone:");
        int yeardron = sc.nextInt();
        System.out.println("Por favor, digite o preço do drone com centavos:");
        float valuedron = sc.nextFloat();
        dronQuantity = list.size() + 1;
        dron object = new dron(namedron, dronQuantity, yeardron, valuedron);
        list.add(object);
    }

    static void deletedron() {
        System.out.println("Então você deseja deletar um dado!\nCaso tenha errado, digite cancelar\nPor favor, digite o número do drone: ");
        String input = sc.next();
        if (input.equalsIgnoreCase("cancelar")) {
        } else {
            int inputInt = Integer.parseInt(input);
            list.remove(inputInt - 1);
            for (dron object : list) {
                list.get(list.indexOf(object)).setdronID(list.indexOf(object) + 1);
            }
        }
    }

    static void updatedron() {
        System.out.println("Então você deseja alterar o dado de um drone!\nPor favor, digite o número do drone: ");
        int i = sc.nextInt();
        System.out.println("Selecione a opção que deseja alterar do drone: \n1. Nome do drone;\n2. Ano do drone;\n3. Preço do drone;\n4. Não alterar nada.");
        int i2 = sc.nextInt();
        switch (i2) {
            case 1:
                System.out.println("Ok, vamos mudar o nome do drone.\n Por favor, digite o novo nome do drone: ");
                String dronModel = sc.next();
                list.get(i - 1).setdronModel(dronModel);
                break;
            case 2:
                System.out.println("Ok, vamos mudar o ano do drone.\n Por favor, digite o novo ano do drone: ");
                int dronYear = sc.nextInt();
                list.get(i - 1).setdronYear(dronYear);
                break;
            case 3:
                System.out.println("Ok, vamos mudar o preço do drone.\n Por favor, digite o preço nome do drone: ");
                float dronPrice = sc.nextFloat();
                list.get(i - 1).setdronPrice(dronPrice);
                break;
            case 4:
                System.out.println("Não haverá alteração em nada, você retornará ao menu inicial!\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
                break;
        }
    }

    static void readdrons() {
        for (dron object : list) {
            System.out.println(object);
        }

    }



}
