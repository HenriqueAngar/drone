package br.dio.com;

class dron {

    String dronModel;
    int dronID;
    int dronYear;
    float dronPrice;

    public String getdronModel () {return dronModel;}

    public void setdronModel (String dronModel) {
        this.dronModel = dronModel;
    }

    public int getdronID () {
        return dronID;
    }

    public void setdronID (int dronID) {
        this.dronID = dronID;
    }

    public int getdronYear () {
        return dronYear;
    }

    public void setdronYear (int dronYear){
        this.dronYear = dronYear;
    }

    public float getdronPrice () {
        return dronPrice;
    }

    public void setdronPrice (float dronPrice) {
        this.dronPrice = dronPrice;
    }



    public dron (String dronModelVariable, int dronIDVariable, int dronYearVariable, float dronPriceVariable ) {
        dronModel = dronModelVariable;
        dronID = dronIDVariable;
        dronYear = dronYearVariable;
        dronPrice = dronPriceVariable;
    }

    public String toString () {
        return "--------------\ndrone número: " + dronID + "\nModelo: " + dronModel + "\nAno: " + dronYear + "\nValor: " + dronPrice + "\n--------------";
    }
}
